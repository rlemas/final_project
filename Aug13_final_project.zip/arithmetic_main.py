# -*- coding: utf-8 -*-
"""
Created on Mon Aug  9 13:50:19 2021

@author: edgar
"""

from arithmetic import *
import turtle
from tkinter import *
"""
        Label(text="Contact List").grid(row=0,column=0,columnspan=2)
        Text(width=30,height=15).grid(row=1,rowspan=9, column=0,columnspan=2,padx=20)
        Button(text="Display Contact").grid(row=10, column=0,columnspan=2,pady=10)
        Label(text="Last Name:").grid(row=11, column=0,pady=10)
        Entry().grid(row=11,column=1)
        Button(text="Search").grid(row=12,column=0,columnspan=2)
"""

class Application(Frame):
    
    def __init__(self, master):
        '''initialise frame'''
        super(Application, self).__init__(master)
        self.grid()
        self.create_main_window()
        

  
    def create_main_window(self):
        
        """
        title_arithmetic = Label(text="Arithmetic Sequence Calculator")
        title_arithmetic.pack(side='top')
        frame = Frame(root)
        frame.pack(side='top')
        
        first_term = Label(frame, text="first term")
        first_term.pack(side='left')
        
        nth_term = Label(frame, text="nth term")
        nth_term.pack(side='bottom')
        """
        
    
        # Label(self, text = 'Arithmetic Sequence Calculator'
        #       ).grid(row = 1, column = 0, columnspan = 4)
        
        # Label(self, text = 'Arithmetic').grid(row='0',column='0')
        # Label(self, text = 'Sequence').grid(row='0',column='1')
        # Label(self, text = 'Calculator').grid(row='0',column='2')
        # Label(self, text = 'dummy ').grid(row='0',column='3')
        
        
        Label(self, text = 'First term: ').grid(row = 0, column = 0, pady = 5) 
        self.first_term = Entry(self) # input 1
        self.first_term.grid(row = 0, column = 1, pady = 5)
        
        Label(self, text = 'Sequence: ', width = "10").grid(row = 4, column = 0, pady = 5)
        self.result_seq = Label(text = "Results", bg = "green", fg = "white", width="22")
        self.result_seq.grid(row = 6, column = 0, padx = 2, pady = 2) # output 1
        
        Label(self, text = 'nth term: ').grid(row = 1, column = 0, pady = 5)
        self.nth_term = Entry(self) # input 2
        self.nth_term.grid(row = 1, column = 1, pady = 5)
        
        Label(self, text = 'nth element: ').grid(row = 4, column = 1, pady = 5)
        self.result_elem = Label(text = "Element", bg = "green", fg = "white", width="10")
        self.result_elem.grid(row = 6, column = 1, padx = 2, pady = 2) # output 2
        
        Label(self, text = 'common diff: ').grid(row = 2, column = 0, pady = 5)
        self.common_diff = Entry(self) # input 3
        self.common_diff.grid(row = 2, column = 1, pady = 5)
        
        Label(self, text = 'Sum Series: ').grid(row = 4, column = 2, pady = 5)
        self.result_sum = Label(text = "Sum", bg = "green", fg = "white", width="10")
        self.result_sum.grid(row = 6, column = 2, padx = 2, pady = 2) # output 3
        
        
        Button(self, text = 'Calculate', command = self.calculate_arith
               ).grid(row = 3, column = 0, pady = 5)
        
        #Label(self, text = 'First term: ').grid(row = 8, column = 0, pady = 5) 
 
        fill="WENS"
        button = Button(text="Exit", command=self.master.destroy)
        button.grid(row=7, column=0, sticky=fill)
        
        
    def calculate_arith(self):
        
        f_term = int(self.first_term.get())
        n_term = int(self.nth_term.get())
        c_term = int(self.common_diff.get())
                
        arith = arithmetic(f_term, n_term, c_term)
        
        arith_sum = arith.sum()
        arith_seq = arith.sequence()
        elem = arith.sequence()
        last_elem = elem[-1]
        print(f'Arithmetic Sum is {arith_sum}')
        print(f'Arithmetic Sequence is {arith_seq}')
        print(f'Arithmetic Sequence last element {last_elem}')
        
        self.result_seq.config(text = str(arith_seq), bg = "green", fg = "white")
        self.result_elem.config(text = str(elem[-1]), bg = "green", fg = "white")
        self.result_sum.config(text = str(arith_sum), bg = "green", fg = "white")

        
    def calculate_geo(self):
        pass
        

def main():
    
    
    # first_term = int(input('Enter 1st term:') )
    # last_term = int(input('Enter nth number:'))
    # common_ratio = int(input('Enter common ratio:'))
    
    first_term = 2
    nth_term = 23
    common_diff = 3
    
    print(f'First Term {first_term}')
    print(f'nth numner {last_term}')
    print(f'Common Ratio {common_ratio}')
    
    #arith = arithmetic(2, 23, 3)
    arith = arithmetic(first_term, nth_term, common_diff)
    print(f'Arithmetic Sum is {arith.sum()}')
    print(f'Arithmetic Sequence is {arith.sequence()}')
    
#main()

root = Tk()
root.geometry("600x450+900+300")
# root.grid_columnconfigure(10, minsize=100)
# root.grid_rowconfigure(5, minsize=100)
# col_count, row_count = root.grid_size()

# print(col_count)
# print(row_count)

# for col in range(col_count):
#     root.grid_columnconfigure(col, minsize=20)
    
# for row in range(row_count):
#     root.grid_rowconfigure(row, minsize=20)

root.title('Arithmetic & Geometric Sequence Calculator')
app = Application(root)
root.mainloop()









"""
    sc = turtle.Screen()
    sc.cv._rootwindow.resizable(False, False)
    sc.screensize()
    #sc.setup(width = 1.0, height = 1.0)
    sc.title("Arithmetic & Geometric Sequence Calculator by Team 2")
    sc.bgcolor('#C5D3E8')
    sc.setup(width = 600, height = 350)
    sc.tracer(0)
         
    #name = turtle.textinput("Personal Detail", "Name")
    
    # first_term = int(input('Enter 1st term:') )
    # last_term = int(input('Enter nth number:'))
    # common_ratio = int(input('Enter common ratio:'))
    
    first_term = 1
    last_term = 2
    common_ratio = 3
    
    print(f'First Term {first_term}')
    print(f'nth numner {last_term}')
    print(f'Common Ratio {common_ratio}')
    
    #arith = arithmetic(2, 23, 3)
    arith = arithmetic(first_term, last_term, common_ratio)
    print(f'Arithmetic Sum is {arith.sum()}')
    print(f'Arithmetic Sequence is {arith.sequence()}')
    turtle.done()
"""


# Label(text="New Contact").grid(row=0,column=2,columnspan=2)
# Label(text="First Name:").grid(row=1,column=2,sticky=E)
# Entry().grid(row=1,column=3)        
        
        #Label(self, text = 'Sequence: ').grid(row = 5, column = 7)
        #self.resultLabel = Label(text = "Results", bg = "green", fg = "white")


        
        #Label(self, text = 'nth element: ').grid(row = 4, column = 4, sticky = W)
        #Label(self, text = 'Sum or numbers: ').grid(row = 5, column = 4, sticky = W)
        
        
        #self.arith_sum = Entry(self)
        #self.arith_sum.grid(row = 5, column = 5, sticky = W)
        
        #print(self.get_f_term())

        #self.result_txt = Text(self, width = 80, height = 15, wrap = WORD)
        #self.result_txt.grid(row = 6, column = 0, columnspan = 4)
